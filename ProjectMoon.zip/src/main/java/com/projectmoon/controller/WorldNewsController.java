package com.projectmoon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/worldNews")
public class WorldNewsController {
	
	
	
	@RequestMapping(value="/mainView")
	public String worldNewsMain() {
		System.out.println("어서오세요 뉴스 화면입니다.");
		
		return "/worldnews/main";
	}

}
