package com.projectmoon.persistence;

import java.util.List;
import java.util.Map;


import com.projectmoon.domain.AccountBookVO;
import com.projectmoon.domain.CommonVO;




public interface CdCommonDao {
	
	// 공통코드 코드 가져오기
	public List<CommonVO> selectCode(CommonVO commonVO);
	
	
	
	
	
	
	
	
	
	
}
