package com.projectmoon.persistence;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.projectmoon.domain.WorldnewsVO;

@Repository
//@Component
//- 영속 계층(Persistence Layer)의 DB 관련 기능을 담당
//- Spring Component bean으로 등록함
//- 스프링 프레임워크가 bean을 생성하기 위해서는
//	 root-context.xml에 bean으로 등록해야 함
//- <context: component-scan .. />
public class WorldnewsDaoImple implements WorldnewsDao{

	@Override
	public int InsertEconomicIndicator(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int InsertNews(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<WorldnewsVO> SelectEconomicIndicator(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorldnewsVO> SelectNews(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int UpdateEconomicIndicator(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int UpdateNews(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int DeleteEconomicIndicator(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int DeleteNews(WorldnewsVO worldnewsVO) {
		// TODO Auto-generated method stub
		return 0;
	}

}
