package com.projectmoon.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.projectmoon.domain.AccountBookVO;
import com.projectmoon.domain.CommonVO;


public interface CdCommonService {
		
		// 코드 불러오기
		public List<CommonVO> selectCode(CommonVO commonvo);
		

}

